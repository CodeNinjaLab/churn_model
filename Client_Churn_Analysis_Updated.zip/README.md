# Client Churn Analysis Dashboard

This project involves analyzing client churn using a synthetic dataset.
We train a logistic regression model to predict churn based on various client features.

## Features
- `tenure`: Time with company (months)
- `monthly_charges`: Monthly bill amount
- `total_charges`: Lifetime bill
- `num_support_calls`: Number of support calls
- `uses_internet`: Whether client uses internet (0/1)
- `contract_type`: Contract type (0=monthly, 1=1-year, 2=2-year)

## Output
The script trains a logistic regression model and outputs:
- Accuracy
- Confusion matrix
- Saved model (`churn_model.pkl`)

Run the script:
```bash
python churn_model.py
```
